
<div id="wowslider-container1">
<div class="ws_images"><ul>
		<li><img src="slide/data1/images/img_6.jpg" alt="Auditorium" title="Auditorium" id="wows1_0"/></li>
		<li><img src="slide/data1/images/img1.jpg" alt="Shaheed Minar" title="Shaheed Minar" id="wows1_1"/></li>
		<li><img src="slide/data1/images/img2.jpg" alt="RUET Gate" title="RUET Gate" id="wows1_2"/></li>
		<li><img src="slide/data1/images/img3.jpg" alt="4th Convocation" title="4th Convocation" id="wows1_3"/></li>
		<li><img src="slide/data1/images/img4.jpg" alt="4th Convocation" title="4th Convocation" id="wows1_4"/></li>
		<li><img src="slide/data1/images/img5.jpg" alt="4th Convocation" title="4th Convocation" id="wows1_5"/></li>
	</ul></div>
	<div class="ws_bullets"><div>
		<a href="#" title="Auditorium"><span><img src="slide/data1/tooltips/img_6.jpg" alt="Auditorium"/>1</span></a>
		<a href="#" title="Shaheed Minar"><span><img src="slide/data1/tooltips/img1.jpg" alt="Shaheed Minar"/>2</span></a>
		<a href="#" title="RUET Gate"><span><img src="slide/data1/tooltips/img2.jpg" alt="RUET Gate"/>3</span></a>
		<a href="#" title="4th Convocation"><span><img src="slide/data1/tooltips/img3.jpg" alt="4th Convocation"/>4</span></a>
		<a href="#" title="4th Convocation"><span><img src="slide/data1/tooltips/img4.jpg" alt="4th Convocation"/>5</span></a>
		<a href="#" title="4th Convocation"><span><img src="slide/data1/tooltips/img5.jpg" alt="4th Convocation"/>6</span></a>
	</div></div>
<div class="ws_shadow"></div>
</div>	


<script type="text/javascript" src="slide/engine1/wowslider.js"></script>
<script type="text/javascript" src="slide/engine1/script.js"></script>
