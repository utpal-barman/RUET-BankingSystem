        <!-- End of main container -->
      </div> 
      
      <br> <br> <br> <br>

<!--    Footer with Copyright -->
        <div class="footer">
            <div class="container-fluid" style="background: black; color: white; padding: 20px">
                <center> Copyright © UTPAL BARMAN <br>
                         Department of Computer Science &amp Engineering (CSE), <br>
                         Rajshahi University of Engineering &amp Technology (RUET), <?php echo date("Y"); ?> </center>
            </div>
        </div>


<!--Adding Some additional online files-->
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="js/bootstrap.min.js"></script>
    </body>
    
</html>
